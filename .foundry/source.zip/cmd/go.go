package cmd

// "foundry go" or "foundry connect" or "foundry " or "foundry start" or "foundry link"?

import (
  "bytes"
  "mime/multipart"
  "path/filepath"

  "io"
  "log"
  "os"
  "net/http"
  // "io/ioutil"
  "fmt"
  "github.com/spf13/cobra"
  // "github.com/fsnotify/fsnotify"

  "foundry/cli/rwatch"
  "foundry/cli/auth"
  "foundry/cli/zip"

  "github.com/gorilla/websocket"
)

var goCmd = &cobra.Command{
  Use:    "go",
  Short:  "Connect Foundry to your project and GO!",
  Long:   "",
  Run:    runGo,
}

func init() {
  rootCmd.AddCommand(goCmd)
}

func runGo(cmd *cobra.Command, args []string) {
  // Connect to pod
  token, err := getToken()
  if err != nil {
    log.Fatal("getToken error", err)
  }

  // Connect to websocket
  c, _, err := websocket.DefaultDialer.Dial("ws://127.0.0.1:3500/ws", nil)
	if err != nil {
		log.Fatal("WS dial error:", err)
	}
	defer c.Close()

  go func() {
		for {
			_, message, err := c.ReadMessage()
			if err != nil {
				log.Println("WS error:", err)
				return
			}
			log.Printf("Autorun message: %s", message)
		}
	}()


  // Start file watcher
  w, err := rwatch.New()
  if err != nil {
    log.Fatal("Watcher error", err)
  }
  defer w.Close()

  done := make(chan bool)
  go func() {
    for {
      select {
      case _ = <-w.Events:
        // log.Println(e)

        // TODO: Send binary data with websocket
        upload(c, token)
      case err := <-w.Errors:
				log.Println("watcher error:", err)
      }
    }
  }()

  err = w.AddRecursive(conf.RootDir)
  if err != nil {
    log.Println(err)
  }
  <-done
}

func getToken() (string, error) {
  a := auth.New()
  a.LoadTokens()
  if err := a.RefreshIDToken(); err != nil {
    return "", err
  }
  return a.IDToken, nil
}

func upload(c *websocket.Conn, token string) {
  ignore := []string{"node_modules", ".git", ".foundry"}
  // Zip project
  path, err := zip.ArchiveDir(conf.RootDir, ignore)
  if err != nil {
    log.Fatal(err)
  }

  // Read file in chunks and send each chunk
  file, err := os.Open(path)
  if err != nil {
		log.Fatal(err)
	}
  defer file.Close()

  bufferSize := 1024 // 1024B
  buffer := make([]byte, bufferSize)

  for {
    bytesread, err := file.Read(buffer)

    if err != nil {
      if err != io.EOF {
        log.Println(err)
      }

      break
    }

    log.Println("bytes read: ", bytesread)
    log.Println("bytestream to string: ", string(buffer[:bytesread]))
  }


  // Send to cloud
  req, err := newFileUploadReq(path, token)
   if err != nil {
    log.Println("error file upload req", err)
  }
  client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		log.Fatal(err)
	} else {
		body := &bytes.Buffer{}
		_, err := body.ReadFrom(resp.Body)
    if err != nil {
			log.Fatal(err)
		}
    resp.Body.Close()
		// fmt.Println(resp.StatusCode)
		// fmt.Println(resp.Header)
		fmt.Println(body)
	}
}

func newFileUploadReq(path, token string) (*http.Request, error) {
  file, err := os.Open(path)
  if err != nil {
		return nil, err
	}
  defer file.Close()

  body := &bytes.Buffer{}
  writer := multipart.NewWriter(body)
  part, err := writer.CreateFormFile("file", filepath.Base(path))
	if err != nil {
		return nil, err
  }

  _, err = io.Copy(part, file)
  writer.WriteField("token", token)
  err = writer.Close()
  if err != nil {
		return nil, err
  }

  url := "http://127.0.0.1:8081/run"
  // url := "https://ide.foundryapp.co/run"

  req, err := http.NewRequest("POST", url, body)
	req.Header.Set("Content-Type", writer.FormDataContentType())
	return req, err
}