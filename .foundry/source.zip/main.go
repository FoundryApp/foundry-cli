package main

import (
	// "github.com/spf13/cobra"
	"foundry/cli/cmd"
)

func main() {
	cmd.Execute()
}
